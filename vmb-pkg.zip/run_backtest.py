"""
Volume Momentum Bot - Backtest Runner
Descarga datos REALES de Binance (endpoint público, sin API keys) y corre
el backtest. Si no hay conexión, cae a datos simulados marcándolo claramente.
"""
import pandas as pd
import numpy as np
import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from strategy import VolumeMomentumStrategy
from risk_manager import RiskManager
from backtester import Backtester

# Intenta importar requests; es dependencia del proyecto.
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def fetch_real_klines(symbol='BTCUSDT', interval='1h', limit=500):
    """Descarga velas reales de Binance vía endpoint público (sin API key)."""
    if not HAS_REQUESTS:
        return None
    url = 'https://api.binance.com/api/v3/klines'
    params = {'symbol': symbol, 'interval': interval, 'limit': limit}
    try:
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        raw = r.json()
        df = pd.DataFrame(raw, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_asset_volume', 'trades',
            'taker_buy_base', 'taker_buy_quote', 'ignore'
        ])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        return df[['timestamp', 'open', 'high', 'low', 'close', 'volume']].reset_index(drop=True)
    except Exception as e:
        print(f"  [aviso] No se pudieron descargar datos reales ({e}). Usando simulados.")
        return None


def generate_realistic_data(seed=42):
    """Genera datos simulados BTC-like si no hay conexión."""
    np.random.seed(seed)
    n = 500
    dates = pd.date_range(start='2024-01-01', periods=n, freq='1h')
    price = 42000.0
    prices, volumes = [], []
    for i in range(n):
        trend = np.random.choice([-1, 1]) * 0.001 if i % 100 == 0 else 0
        change = np.random.normal(0.0002 + trend, 0.008)
        price *= (1 + change)
        prices.append(price)
        base_vol = np.random.randint(800, 3000)
        vol_spike = np.random.uniform(2.0, 5.0) if abs(change) > 0.01 else 1.0
        volumes.append(int(base_vol * vol_spike))
    return pd.DataFrame({
        'timestamp': dates,
        'open': prices,
        'high': [p * (1 + abs(np.random.normal(0, 0.004))) for p in prices],
        'low': [p * (1 - abs(np.random.normal(0, 0.004))) for p in prices],
        'close': prices,
        'volume': volumes
    })


def run_backtest(symbol='BTCUSDT', interval='1h', limit=500):
    print("=" * 60)
    print("VOLUME MOMENTUM BOT - BACKTEST")
    print("=" * 60)

    df = fetch_real_klines(symbol, interval, limit)
    source = 'REAL (Binance)' if df is not None else 'SIMULADO (sin conexión)'
    if df is None:
        df = generate_realistic_data()
    print(f"Fuente de datos: {source}")
    print(f"Velas: {len(df)} | Símbolo: {symbol} | Intervalo: {interval}")
    print(f"Rango precio: ${df['close'].min():.0f} - ${df['close'].max():.0f}")
    print(f"Período: {df['timestamp'].min()} -> {df['timestamp'].max()}")

    configs = [
        {'name': 'Default', 'rsi_period': 14, 'rsi_ob': 70, 'rsi_os': 30,
         'ema_fast': 9, 'ema_slow': 21, 'vol_period': 20, 'vol_mult': 1.5},
        {'name': 'Aggressive', 'rsi_period': 10, 'rsi_ob': 75, 'rsi_os': 25,
         'ema_fast': 5, 'ema_slow': 13, 'vol_period': 14, 'vol_mult': 1.3},
        {'name': 'Conservative', 'rsi_period': 21, 'rsi_ob': 65, 'rsi_os': 35,
         'ema_fast': 12, 'ema_slow': 26, 'vol_period': 30, 'vol_mult': 2.0},
    ]

    best_report = None
    best_name = ''
    for cfg in configs:
        name = cfg.pop('name')
        strategy = VolumeMomentumStrategy(**cfg)
        risk = RiskManager(risk_per_trade=0.01, stop_loss_pct=0.02, take_profit_pct=0.04)
        bt = Backtester(strategy, risk, initial_balance=1000)
        report = bt.run(df)
        print(f"\n--- {name} Config ---")
        for k, v in report.items():
            print(f"  {k}: {v:.2f}" if isinstance(v, float) else f"  {k}: {v}")
        if report.get('total_trades', 0) > 0 and (best_report is None or report.get('win_rate', 0) > best_report.get('win_rate', 0)):
            best_report = report
            best_name = name

    if best_report:
        print(f"\n{'=' * 60}\nMEJOR CONFIG: {best_name}\n{'=' * 60}")
        for k, v in best_report.items():
            print(f"  {k}: {v:.2f}" if isinstance(v, float) else f"  {k}: {v}")
        # Guardar trades
        strategy = VolumeMomentumStrategy(**configs[0])
        risk = RiskManager()
        bt = Backtester(strategy, risk, initial_balance=1000)
        bt.run(df)
        if bt.trades:
            pd.DataFrame(bt.trades).to_csv('backtest_trades.csv', index=False)
            print("\nTrades guardados en backtest_trades.csv")
    else:
        print("\nNo se generaron operaciones en este set de datos.")

    # Resumen para la web/landing (guardado como JSON)
    summary = {
        'source': source,
        'symbol': symbol,
        'interval': interval,
        'candles': len(df),
        'price_min': float(df['close'].min()),
        'price_max': float(df['close'].max()),
        'best_config': best_name,
        'best_report': {k: (float(v) if isinstance(v, float) else v) for k, v in best_report.items()} if best_report else None
    }
    with open('backtest_summary.json', 'w') as f:
        json.dump(summary, f, indent=2)
    return best_report


if __name__ == '__main__':
    run_backtest()